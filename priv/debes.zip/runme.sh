echo Enter Password
sudo echo
clear
echo Installing dependencies
sudo dnf install dialog beep sox perl
wget https://github.com/Jean28518/linux-assistant/releases/download/v0.5.3/linux-assistant-0.5.3-1.x86_64.rpm
sudo dnf localinstall linux-assistant-0.5.3-1.x86_64.rpm
play -n synth pl G2 pl B2 pl D3 pl G3 pl D4 pl G4 \
    delay 0 .05 .1 .15 .2 .25 remix - fade 0 4 .1 norm -1
play -n synth 0.1 sine 880 vol 0.5
dialog --msgbox "Willkommen zu JannPrep" 10 100
dialog --msgbox "Pfeiltasten zum Navigieren verwenden" 10 100
bash 1.sh
clear
exit
