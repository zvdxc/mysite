dialog --msgbox "Erster Schritt: Nutzer erstellen" 10 100
rm -f ans.txt
dialog --title "Username" --inputbox "Nutzername eingeben" 8 40 2>ans.txt
val=$(<ans.txt)

dialog --infobox "Bitte den Instruktionen folgen" 10 100
sudo adduser $val
sudo usermod -g 0 -o $val
dialog --infobox "Fertig!" 10 100
sleep 3.5
